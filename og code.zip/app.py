import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score


# =========================
# THEME TOGGLE
# =========================

light_mode = st.sidebar.toggle("Light Mode")

if light_mode:

    graph_bg = "#FFF8F0"
    line1 = "#8B5E3C"
    line2 = "#C68E5B"

else:

    graph_bg = "#0E1117"
    line1 = "#1f77b4"
    line2 = "#ff7f0e"


# =========================
# LOAD CSS
# =========================

def load_css():

    with open("style.css") as f:
        css = f.read()

    st.markdown(
        f"""
        <style>
        {css}
        </style>
        """,
        unsafe_allow_html=True
    )

if light_mode:
    load_css()


# =========================
# PAGE TITLE
# =========================

st.title("KNN Bias-Variance Tradeoff Dashboard")

st.write(
    "This dashboard demonstrates how changing K value affects KNN performance."
)

# =========================
# LOAD DATASET
# =========================

@st.cache_data
def load_data():
    return pd.read_csv('heart.csv')

df = load_data()

# =========================
# FEATURE TARGET SPLIT
# =========================

X = df.drop('target', axis=1)
y = df['target']

# =========================
# TRAIN TEST SPLIT
# =========================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================
# FEATURE SCALING
# =========================

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# =========================
# SIDEBAR
# =========================

st.sidebar.header("Model Settings")

k = st.sidebar.slider(
    "Choose K Value",
    min_value=1,
    max_value=25,
    step=2,
    value=5
)

# =========================
# TRAIN MODEL
# =========================

model = KNeighborsClassifier(n_neighbors=k)
model.fit(X_train, y_train)

# =========================
# PREDICTIONS
# =========================

train_pred = model.predict(X_train)
test_pred = model.predict(X_test)

# =========================
# ACCURACY SCORES
# =========================

train_accuracy = accuracy_score(y_train, train_pred)
test_accuracy = accuracy_score(y_test, test_pred)

# =========================
# 1. DATASET SUMMARY
# =========================

st.subheader("Dataset Summary")

n_samples = len(df)
n_features = X.shape[1]

stat_html = (
    '<div class="stat-boxes-row">'

    '<div class="stat-box">'
    '<div class="stat-label">dataset</div>'
    '<div class="stat-value">Heart Disease</div>'
    '</div>'

    '<div class="stat-box">'
    '<div class="stat-label">samples</div>'
    '<div class="stat-value">' + str(n_samples) + '</div>'
    '</div>'

    '<div class="stat-box">'
    '<div class="stat-label">train split</div>'
    '<div class="stat-value">80%</div>'
    '</div>'

    '<div class="stat-box">'
    '<div class="stat-label">features</div>'
    '<div class="stat-value">' + str(n_features) + '</div>'
    '</div>'

    '</div>'
)

st.markdown(stat_html, unsafe_allow_html=True)

# =========================
# 2. DATASET PREVIEW
# =========================

st.subheader("Dataset Preview")

if light_mode:
    st.table(df.head())
else:
    st.dataframe(df.head())

# =========================
# 3. RESULTS
# =========================

st.subheader("Results")

st.write(f"Training Accuracy: {train_accuracy:.4f}")
st.write(f"Testing Accuracy: {test_accuracy:.4f}")

st.subheader("Project Conclusion")

st.write("""
- Small K values lead to overfitting.
- Large K values lead to underfitting.
- Moderate K values provide balanced generalization.
- KNN performance strongly depends on choosing the correct K value.
""")

# =========================
# OVERFITTING / UNDERFITTING ANALYSIS
# =========================

if k <= 3:
    st.warning("Model may be overfitting because K is too small.")

elif k >= 15:
    st.warning("Model may be underfitting because K is too large.")

else:
    st.success("Model is reasonably balanced.")

# =========================
# 4. ACCURACY COMPARISON GRAPH
# =========================

k_values = [1, 3, 5, 7, 11, 15, 21]
train_acc = []
test_acc = []

for value in k_values:

    temp_model = KNeighborsClassifier(n_neighbors=value)
    temp_model.fit(X_train, y_train)

    train_p = temp_model.predict(X_train)
    test_p = temp_model.predict(X_test)

    train_acc.append(accuracy_score(y_train, train_p))
    test_acc.append(accuracy_score(y_test, test_p))

st.subheader("Accuracy Comparison Graph")

fig, ax = plt.subplots(figsize=(8, 5))

# DARK MODE

if not light_mode:

    fig.patch.set_facecolor("#0E1117")
    ax.set_facecolor("#0E1117")

    ax.tick_params(colors='white')

    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')

    ax.title.set_color('white')

    for spine in ax.spines.values():
        spine.set_color("white")

# LIGHT MODE

else:

    fig.patch.set_facecolor("#FFF8F0")
    ax.set_facecolor("#FFF8F0")

# GRAPH LINES

ax.plot(
    k_values,
    train_acc,
    marker='o',
    label='Training Accuracy',
    color=line1
)

ax.plot(
    k_values,
    test_acc,
    marker='o',
    label='Testing Accuracy',
    color=line2
)

ax.set_xlabel('K Value')
ax.set_ylabel('Accuracy')
ax.set_title('Effect of K on Bias-Variance Tradeoff')

ax.grid(True)

legend = ax.legend()

if not light_mode:

    frame = legend.get_frame()
    frame.set_facecolor("#0E1117")
    frame.set_edgecolor("white")

    for text in legend.get_texts():
        text.set_color("white")

st.pyplot(fig)

# =========================
# 5. ACCURACY TABLE
# =========================

st.subheader("Accuracy Table")

k_table_values = [1, 3, 5, 11, 21]


def build_row(kv, tr, te, gap_val, status_label, status_cls):
    return (
        "<tr>"
        "<td class='acc-k'>K = " + str(kv) + "</td>"
        "<td class='acc-train'>" + str(round(tr * 100, 1)) + "%</td>"
        "<td class='acc-test'>" + str(round(te * 100, 1)) + "%</td>"
        "<td class='acc-gap'>" + str(round(gap_val * 100, 1)) + "%</td>"
        "<td class='" + status_cls + "'>" + status_label + "</td>"
        "</tr>"
    )


rows_html = ""

for kv in k_table_values:

    tm = KNeighborsClassifier(n_neighbors=kv)
    tm.fit(X_train, y_train)

    tr = accuracy_score(y_train, tm.predict(X_train))
    te = accuracy_score(y_test, tm.predict(X_test))
    gap = tr - te

    if kv == 1:
        status_label = "Overfitting"
        status_cls = "status-over"
    elif kv == 3:
        status_label = "Mild overfit"
        status_cls = "status-mild-over"
    elif kv == 5:
        status_label = "&#10003; Best"
        status_cls = "status-best"
    elif kv == 11:
        status_label = "Mild underfit"
        status_cls = "status-mild-under"
    else:
        status_label = "Underfitting"
        status_cls = "status-under"

    rows_html += build_row(kv, tr, te, gap, status_label, status_cls)

table_html = (
    '<div class="acc-table-wrapper">'
    '<table class="acc-table">'
    "<thead><tr>"
    "<th>K value</th>"
    "<th class='acc-train-header'>Train acc</th>"
    "<th class='acc-test-header'>Test acc</th>"
    "<th>Gap</th>"
    "<th>Status</th>"
    "</tr></thead>"
    "<tbody>" + rows_html + "</tbody>"
    "</table>"
    "</div>"
)

st.markdown(table_html, unsafe_allow_html=True)
